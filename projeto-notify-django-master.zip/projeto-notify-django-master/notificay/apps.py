from django.apps import AppConfig


class NotificayConfig(AppConfig):
    name = 'notificay'
